# -*- coding: utf-8 -*-

import re
from nltk.tokenize import word_tokenize
from Stopwords import stopwords_currencies, stopwords_datesandnumbers, stopwords_generic, stopwords_generic_long, stopwords_geographic, stopwords_names
from Count import word_count,sentence_count, avg_sentence_length, constraining_word_count, uncertainty_word_count
from Fog_Index import fog_index
from Scores import positive_score, negative_score, polarity_score
from complex_words import complex_words_count, complex_words_percent
from Proportions import positive_word_proportion, negative_word_proportion, constraining_word_proportion, uncertainty_word_proportion
from openpyxl import load_workbook

currencies_stopwords = stopwords_currencies(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_Currencies.txt")
        
datesandnumbers_stopwords = stopwords_datesandnumbers(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_DatesandNumbers.txt")
        
generic_stopwords = stopwords_generic(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_Generic.txt")
        
genericlong_stopwords = stopwords_generic_long(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_GenericLong.txt")
        
geographic_stopwords = stopwords_geographic(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_Geographic.txt")
        
names_stopwords = stopwords_names(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_Names.txt")

def analysis():
    """Complete Textual Analysis of QQDMR Sectional Data
    
    This function performs complete textual analysis including text cleaning, stopwords cleaning etc.
    
    Args:
        None
    
    Returns:
        None
    """
    sc = []; wc = []; avg_sent_len = []; cw_c = []; uw_c = []; pos = []; neg = []; pol = []; cwc = []; cwp = []; p_p = []; n_p = []; cw_p = []; uw_p = []; fg_idx = []
    
    for i in range(1, 153):
        try:
            with open(r"C:\Users\singh\Downloads\Assignment\Solution\3. Sectional Data\2. QQDMR\Output{}.txt".format(i), 'r') as in_file:
                input_file = in_file.read()
                
                
        except FileNotFoundError as fnf_error:
            sc.append(None)
            wc.append(None)
            avg_sent_len.append(None)
            cw_c.append(None)
            uw_c.append(None)
            pos.append(None)
            neg.append(None)
            pol.append(None)
            cwp.append(None)
            cwc.append(None)
            p_p.append(None)
            n_p.append(None)
            cw_p.append(None)
            uw_p.append(None)
            fg_idx.append(None)
            continue
        
        sc.append(sentence_count(input_file))
        input_file = input_file.lower()
        input_file = input_file.replace('/', ' / ')
        w = word_tokenize(input_file)
        for j, s in enumerate(w):
            if '\'s' in s:
                w[j-1] = w[j-1] + w[j]
                del w[j]
        
        p = re.compile('(?<!\d)\.|\.(?!\d)')
        w = [p.sub('', x) for x in w]
        p = re.compile("(?<!\w)\'|[\(\)\$,`\-&?\"\!\:;\=\/]")
        w = [p.sub('', x) for x in w]
        w = [x for x in w if x]
        
        X = []
        for word in w:
            if not word in set(generic_stopwords):
                X.append(word)
        
        w = X
        X = []
        for word in w:
            if not word in set(currencies_stopwords):
                X.append(word)
                  
        w = X
        X = []        
        for word in w:
            if not word in set(datesandnumbers_stopwords):
                X.append(word)
        
        w = X
        X = []        
        for word in w:
            if not word in set(genericlong_stopwords):
                X.append(word)
        
        w = X
        X = []        
        for word in w:
            if not word in set(geographic_stopwords):
                X.append(word)
                
        w = X
        X = []
        for word in w:
            if not word in set(names_stopwords):
                X.append(word)
        
        w = X
        for word in w:
            input_file = ' '.join(w)
        
        wc.append(word_count(w))
        avg_sent_len.append(avg_sentence_length())
        
        cw_c.append(constraining_word_count(r"C:\Users\singh\Downloads\Assignment\constraining_dictionary.xlsx"))
        uw_c.append(uncertainty_word_count(r"C:\Users\singh\Downloads\Assignment\uncertainty_dictionary.xlsx"))
        
        pos.append(positive_score(r"C:\Users\singh\Downloads\Assignment\Solution\LM Dictionary words\LM_Positive.txt", w))
        neg.append(negative_score(r"C:\Users\singh\Downloads\Assignment\Solution\LM Dictionary words\LM_Negative.txt", w))
        pol.append(polarity_score(w))
        
        cwc.append(complex_words_count(w))
        cwp.append(complex_words_percent(w))
        
        p_p.append(positive_word_proportion())
        n_p.append(negative_word_proportion())
        
        cw_p.append(constraining_word_proportion())
        uw_p.append(uncertainty_word_proportion())
        
        fg_idx.append(fog_index())

    wb = load_workbook(r"C:\Users\singh\Downloads\Assignment\Solution\Output Data Structure.xlsx")

    sheet = wb.active

    row=2
    while(row <= 153):
        row=2
        for x in pos:
            sheet.cell(row, 21, x)
            row+=1
                
        row=2
        for x in neg:
            sheet.cell(row, 22, x)
            row+=1
                
        row=2
        for x in pol:
            sheet.cell(row, 23, x)
            row+=1
                
        row=2
        for x in avg_sent_len:
            sheet.cell(row, 24, x)
            row+=1
                
        row=2
        for x in cwp:
            sheet.cell(row, 25, x)
            row+=1
            
        row=2
        for x in fg_idx:
            sheet.cell(row, 26, x)
            row+=1
                
        row=2
        for x in cwc:
            sheet.cell(row, 27, x)
            row+=1
                
        row=2
        for x in wc:
            sheet.cell(row, 28, x)
            row+=1
                
        row=2
        for x in uw_c:
            sheet.cell(row, 29, x)
            row+=1
                
        row=2
        for x in cw_c:
            sheet.cell(row, 30, x)
            row+=1
                
        row=2
        for x in p_p:
            sheet.cell(row, 31, x)
            row+=1
                
        row=2
        for x in n_p:
            sheet.cell(row, 32, x)
            row+=1
                
        row=2
        for x in uw_p:
            sheet.cell(row, 33, x)
            row+=1
                
        row=2
        for x in cw_p:
            sheet.cell(row, 34, x)
            row+=1
        
    wb.save(r"C:\Users\singh\Downloads\Assignment\Solution\Output Data Structure.xlsx")
