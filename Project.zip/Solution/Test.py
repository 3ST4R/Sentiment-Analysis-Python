# -*- coding: utf-8 -*-
#
#--------==========================================================================================================--------
#        _______  _____  _   _  _______           _               _             _                 ____  ___   ____
#           |    |        \ /      |     |   |   / \   |         / \   |\  |   / \   |     \  /  /       |   /
#           |    |~~~~     \       |     |   |  |___|  |        |___|  | \ |  |___|  |      \/   \~~~\   |   \~~~\
#           |    |_____  _/ \_     |     \___/  |   |  |___     |   |  |  \|  |   |  |___   /    ____/  _|_  ____/
#
#--------==========================================================================================================--------

# =========
# Note 1: - 
# =========
#         The functions which have been entered without sufficient arguments are those functions
# which are dependent on other functions for getting their arguments as "default arguments". 
#
# Please make sure to execute the dependent functions first or
# choose to input all the arguments required for the function.

# =========
# Note 2: -
# =========
#         The file paths given in the below functions should be set according to the  
# correct file address referring to the file in the computer system.
#
# Kindly change the file paths of such functions used in the project to the desired destination.
#
# =========
# Note 3: - 
# =========
#       This code only shows the working of different functions used in the project. This is not the actual code.
# Kindly view the "README.docx" file before running the actual code.

# -----------------
# Importing modules
# -----------------
from Count import word_count, sentence_count, avg_sentence_length, constraining_word_count, uncertainty_word_count
from Fog_Index import fog_index
from Scores import positive_score, negative_score, polarity_score
from Proportions import positive_word_proportion, negative_word_proportion, constraining_word_proportion, uncertainty_word_proportion
from complex_words import complex_words_count, complex_words_percent

# -----------------
# Sample Words List
# -----------------
w = ['inferno', 'abide', 'shamed', 'commit', 'changes', 'umbrella', 'abeyance', 'almost', 'achieve', 'assure', 'bankrupt', 'abandon']

# ----------------------
# Sample String of Words
# ----------------------
str_a = 'A Turing machine is a device that manipulates symbols on a strip of tape according to a table of rules. Despite its simplicity, a Turing machine can be adapted to simulate the logic of any computer algorithm, and is particularly useful in explaining the functions of a CPU inside a computer. The "Turing" machine was described by Alan Turing in 1936, who called it an "a(utomatic)-machine". The Turing machine is not intended as a practical computing technology, but rather as a hypothetical device representing a computing machine. Turing machines help computer scientists understand the limits of mechaniacl computation.'

# ---------------------------------------------
# 1. Calculating Word Count from the Words List
# ---------------------------------------------
wc = word_count(w)

# -----------------------------------------------------------------------------------------
# 2. Calculating Sentence Count from the String of Words (rounded off upto 1 decimal place)
# -----------------------------------------------------------------------------------------
sc = sentence_count(str_a)

# -------------------------------------------------------------------------------
# 3. Calculating Average Sentence Length by the formula described in the function
# -------------------------------------------------------------------------------
# ===> Function call without arguments (The arguments from "word_count" and "sentence_count" functions will be taken as default arguments)
# ===> Use of the above 2 functions is a must for this type of function call to work (See Note 1).
asl = avg_sentence_length()

# ===> Function call with arguments, where 1st argument is a list of words and 2nd argument is a string of words 
asl0 = avg_sentence_length(w, str_a)

# ---------------------------------------------------------------------------------------
# 4. Calculating Constraining Words Count by getting constraining words from a dictionary 
# ---------------------------------------------------------------------------------------
# ===> Function Call without the list of words argument (Argument from "word_count" function will be taken as default argument)
cw_c = constraining_word_count(r"C:\Users\singh\Downloads\Assignment\constraining_dictionary.xlsx")

# ===> Function Call with all the arguments,
# ===> where 1st argument is the file path of the constraining words dictionary XLSX file and 2nd argument is the list of words
cw_c0 = constraining_word_count(r"C:\Users\singh\Downloads\Assignment\constraining_dictionary.xlsx", w)

# -------------------------------------------------------------------------------------
# 5. Calculating Uncertainty Words Count by getting uncertainty words from a dictionary 
# -------------------------------------------------------------------------------------
# ===> Function Call without the list of words argument (Argument from "word_count" function will be taken as default argument)
uw_c = uncertainty_word_count(r"C:\Users\singh\Downloads\Assignment\uncertainty_dictionary.xlsx")

# ===> Function Call with all the arguments,
# ===> where 1st argument is the file path of the uncertainty words dictionary XLSX file and 2nd argument is the list of words.
uw_c0 = uncertainty_word_count(r"C:\Users\singh\Downloads\Assignment\uncertainty_dictionary.xlsx", w)

# ---------------------------------------------------------------------------------------------------------------
# 6. Calculating Positive Score from a list of words by comparing them from Positive words present in a .TXT file
# ---------------------------------------------------------------------------------------------------------------
p = positive_score(r"C:\Users\singh\Downloads\Assignment\Solution\LM Dictionary words\LM_Positive.txt", w)

# ---------------------------------------------------------------------------------------------------------------
# 7. Calculating Negative Score from a list of words by comparing them from Negative words present in a .TXT file
# ---------------------------------------------------------------------------------------------------------------
n = negative_score(r"C:\Users\singh\Downloads\Assignment\Solution\LM Dictionary words\LM_Negative.txt", w)

# ---------------------------------------------------------------------------------------
# 8. Calculating Polarity Score from a list of words by the formula given in the function
# ---------------------------------------------------------------------------------------
# ===> Function Call without File path arguments of Positive and Negative words TXT file
# ===> (File path arguments from "positive_score" and "negative_score" functions will be taken as default arguments)
pol = polarity_score(w)

# ===> Function Call with all the arguments,
# ===> where 1st argument is the list of words, 2nd and 3rd arguments are the file paths of positive and negative words TXT files respectively.
pol0 = polarity_score(w, r"C:\Users\singh\Downloads\Assignment\Solution\LM Dictionary words\LM_Positive.txt", r"C:\Users\singh\Downloads\Assignment\Solution\LM Dictionary words\LM_Negative.txt")

# -------------------------------------------------------
# 9. Calculating Complex Words Count from a list of words
# -------------------------------------------------------
cwc = complex_words_count(w)

# ---------------------------------------------------------------------------------------------------------
# 10. Calculating Percent of Complex Words in a list of words (returns a float value not multiplied by 100)
# ---------------------------------------------------------------------------------------------------------
# ===> Function Call without arguments (Argument from "complex_words_count" will be taken as default argument)
cwp = complex_words_percent()

# ===> Function Call with list of words argument 
cwp0 = complex_words_percent(w)

# ------------------------------------------------------------------------------
# 11. Calculating Positive Words Proportion by the formula given in the function
# ------------------------------------------------------------------------------
# ===> Function Call without arguments (Arguments from "positive_score" and "word_count" will be taken as default arguments)
p_p = positive_word_proportion()

# ===> Function Call with all the arguments,
# ===> where 1st argument is the file path of Positive words TXT file and 2nd argument is the list of words
p_p0 = positive_word_proportion(r"C:\Users\singh\Downloads\Assignment\Solution\LM Dictionary words\LM_Positive.txt", w)

# ------------------------------------------------------------------------------
# 12. Calculating Negative Words Proportion by the formula given in the function
# ------------------------------------------------------------------------------
# ===> Function Call without arguments (Arguments from "negative_score" and "word_count" will be taken as default arguments)
n_p = negative_word_proportion()

# ===> Function Call with all the arguments,
# ===> where 1st argument is the file path of Negative words TXT file and 2nd argument is the list of words
n_p0 = negative_word_proportion(r"C:\Users\singh\Downloads\Assignment\Solution\LM Dictionary words\LM_Negative.txt", w)

# ----------------------------------------------------------------------------------
# 13. Calculating Constraining Words Proportion by the formula given in the function
# ----------------------------------------------------------------------------------
# ===> Function Call without arguments (Arguments from "constraining_word_count" and "word_count" will be taken as default arguments)
cw_p = constraining_word_proportion()

# ===> Function Call with all the arguments,
# ===> where 1st argument is the file path of dictionary of constraining words XLSX file and 2nd argument is the list of words
cw_p0 = constraining_word_proportion(r"C:\Users\singh\Downloads\Assignment\constraining_dictionary.xlsx", w)

# ---------------------------------------------------------------------------------
# 14. Calculating Uncertainty Words Proportion by the formula given in the function
# ---------------------------------------------------------------------------------
# ===> Function Call without arguments (Arguments from "uncertainty_word_count" and "word_count" will be taken as default arguments)
uw_p = uncertainty_word_proportion()

# ===> Function Call with all the arguments,
# ===> where 1st argument is the file path of dictionary of uncertainty words XLSX file and 2nd argument is the list of words
uw_p0 = uncertainty_word_proportion(r"C:\Users\singh\Downloads\Assignment\uncertainty_dictionary.xlsx", w)

# --------------------------------------------------------------
# 15. Calculating Fog Index by the formula given in the function
# --------------------------------------------------------------
# ===> Function Call without arguments (Arguments from "word_count" and "sentence_count" will be taken as default arguments)
fg_idx = fog_index()

# ===> Function Call with all the arguments,
# ===> where 1st argument is the list of words and 2nd argument is the string of words
fg_idx0 = fog_index(w, str_a)
