# -*- coding: utf-8 -*-
import Count
from Count import avg_sentence_length
from complex_words import complex_words_percent

def fog_index(words_list = None, input_str = None):
    """Fog Index
    
    This function calculates Fog Index
    
    Args:
        words_list (list, optional): List of words. Defaults to None
        input_str (str, optional): Input string. Defaults to None
        
    Returns:
        float: The return value. Fog Index
    """
    if words_list is None:
        words_list = Count.w0
    if input_str is None:
        input_str = Count._str_
    asl = avg_sentence_length(words_list, input_str)
    cwp = complex_words_percent(words_list)
    
    f_index = 0.4*(asl + cwp)
    
    return f_index
