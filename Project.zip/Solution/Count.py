# -*- coding: utf-8 -*-
w0 = []
def word_count(words_list: list):
    """Word Count
    
    This function calculates the number of words in a list of words.
    
    Args:
        words_list (list): List of words
    
    Returns:
        int: The return value. Number of words
    """
    global w0
    w0 = words_list
    wc = len(words_list)
    
    return wc

_str_ = ''
import nltk
nltk.download('punkt')
from nltk import sent_tokenize
def sentence_count(input_str: str):
    """Sentence Count
    
    This function calculates the number of sentences in an input string
    
    Args:
        input_str (str): Input string
    
    Returns:
        int: The return value. Number of sentences
    """
    global _str_
    _str_ = input_str
        
    w = sent_tokenize(input_str)
    
    sc = len(w)
    
    return sc

def avg_sentence_length(words_list = None, input_str = None):
    """Average Sentence Length
    
    This function calculates average sentence length
    
    Args:
        words_list (list, optional): List of words. Defaults to None
    
    Returns:
        float: The return value. Average sentence length
    """
    if words_list is None:
        words_list = w0
    if input_str is None:
        input_str = _str_
    wc = word_count(words_list)
    sc = sentence_count(input_str)
    
    sent_len = wc/sc
    
    return float("{:.1f}".format(sent_len))

f_0 = ''
def constraining_word_count(filepath: str, words_list = None):
    """Number of Constraining Words
    
    This function calculates the number of constraining words
    
    Args:
        filepath (str): File path of constraining word dictionary in XLSX format
        words_list (list, optional): List of words. Defaults to None
    
    Returns:
        int: The return value. Number of constraining words
    """
    global f_0
    f_0 = filepath
    if words_list is None:
        words_list = w0
        
    import xlrd
    
    wb = xlrd.open_workbook(filepath)
    sheet = wb.sheet_by_index(0)
    
    a = set()
    
    for row in range(1, sheet.nrows):
        a.add(sheet.cell_value(row, 0))
        
    a = {x.lower() for x in a}
    a = {x.replace(r'\n', '') for x in a}
    a = {x.replace(' ', '') for x in a}
    
    constraining_wc = 0
    for word in words_list:
        for w in a:
            if w == word:
                constraining_wc+=1
    
    return constraining_wc

f_1 = ''
def uncertainty_word_count(filepath: str, words_list = None):
    """Number of Uncertainty Words
    
    This function calculates the number of uncertainty words
    
    Args:
        filepath (str): File path of Uncertainty words dictionary in XLSX format
        words_list (list, optional): List of words. Defaults to None
    
    Returns:
        int: The return value. Number of Uncertainty Words
    """
    global f_1
    f_1 = filepath
    if words_list is None:
        words_list = w0    

    import xlrd
    
    wb = xlrd.open_workbook(filepath)
    sheet = wb.sheet_by_index(0)
    
    a = set()
    
    for row in range(1, sheet.nrows):
        a.add(sheet.cell_value(row, 0))
        
    a = {x.lower() for x in a}
    a = {x.replace(r'\n', '') for x in a}
    a = {x.replace(' ', '') for x in a}
        
    uncertainty_wc = 0
    
    for word in words_list:
        for w in a:
            if w == word:
                uncertainty_wc+=1
    
    return uncertainty_wc
