# -*- coding: utf-8 -*-
def stopwords_currencies(filepath: str):
    """Stopwords regarding Currencies
    
    This function is used to store stopwords from TXT format to a set
    
    Args:
        filepath (str): File path of Stopwords in TXT format
    
    Returns:
        set: The return value. set(Stopwords) 
    """      
    with open(filepath, 'r') as stopwords:
        stop_words_currencies = {x.lower() for x in stopwords}
        stop_words_currencies = {x.split(r'|')[0] for x in stop_words_currencies}
        stop_words_currencies = {x.replace('\n', '') for x in stop_words_currencies}
        stop_words_currencies = {x.replace(' ', '') for x in stop_words_currencies}
    
    return stop_words_currencies

def stopwords_datesandnumbers(filepath: str):
    """Stopwords regarding Dates and Numbers
    
    This function is used to store stopwords from TXT format to a set
    
    Args:
        filepath (str): File path of Stopwords in TXT format
    
    Returns:
        set: The return value. set(Stopwords) 
    """ 
    with open(filepath, 'r') as stopwords:
        stop_words_datesandnumbers = {x.lower() for x in stopwords}
        stop_words_datesandnumbers = {x.split(r'|')[0] for x in stop_words_datesandnumbers}
        stop_words_datesandnumbers = {x.replace('\n', '') for x in stop_words_datesandnumbers}
        stop_words_datesandnumbers = {x.replace(' ', '') for x in stop_words_datesandnumbers}
    
    return stop_words_datesandnumbers

def stopwords_generic(filepath: str):
    """Generic Stopwords
    
    This function is used to store stopwords from TXT format to a set
    
    Args:
        filepath (str): File path of Stopwords in TXT format
    
    Returns:
        set: The return value. set(Stopwords) 
    """
    with open(filepath, 'r') as stopwords:
        stop_words_generic = {x.lower() for x in stopwords}
        stop_words_generic = {x.replace('\n', '') for x in stop_words_generic}
        stop_words_generic = {x.replace(' ', '') for x in stop_words_generic}
        
    return stop_words_generic

def stopwords_generic_long(filepath: str):
    """Long Generic Stopwords
    
    This function is used to store stopwords from TXT format to a set
    
    Args:
        filepath (str): File path of Stopwords in TXT format
    
    Returns:
        set: The return value. set(Stopwords) 
    """
    with open(filepath, 'r') as stopwords:
        stop_words_genericlong = {x.lower() for x in stopwords}
        stop_words_genericlong = {x.replace('\n', '') for x in stop_words_genericlong}
        stop_words_genericlong = {x.replace(' ', '') for x in stop_words_genericlong}
        
    return stop_words_genericlong

def stopwords_geographic(filepath: str):
    """Stopwords regarding Geography
    
    This function is used to store stopwords from TXT format to a set
    
    Args:
        filepath (str): File path of Stopwords in TXT format
    
    Returns:
        set: The return value. set(Stopwords) 
    """
    with open(filepath, 'r') as stopwords:
        stop_words_geographic = {x.lower() for x in stopwords}
        stop_words_geographic = {x.split(r'|')[0] for x in stop_words_geographic}
        stop_words_geographic = {x.replace('\n', '') for x in stop_words_geographic}
        stop_words_geographic = {x.replace(' ', '') for x in stop_words_geographic}
        
    return stop_words_geographic

def stopwords_names(filepath: str):
    """Stopwords regarding Names
    
    This function is used to store stopwords from TXT format to a set
    
    Args:
        filepath (str): File path of Stopwords in TXT format
    
    Returns:
        set: The return value. set(Stopwords) 
    """
    with open(filepath, 'r') as stopwords:
        stop_words_names = {x.lower() for x in stopwords}
        stop_words_names = {x.split(r'|')[0] for x in stop_words_names}
        stop_words_names = {x.replace('\n', '') for x in stop_words_names}
        stop_words_names = {x.replace(' ', '') for x in stop_words_names}
        
    return stop_words_names
