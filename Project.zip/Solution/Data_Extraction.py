# -*- coding: utf-8 -*-
import xlrd
import requests                                
from bs4 import BeautifulSoup

def extract_data(filepath: str):
    """Data Extraction
    
    This function extracts all the data from the links provided in XLSX workbook
    
    Args:
        filepath (str): File path of the XLSX workbook
        
    Returns:
        None
    """        
    wb = xlrd.open_workbook(filepath)               
    
    sheet = wb.sheet_by_index(0)                   
    X = []
    for row in range(1, sheet.nrows):
        X.append(sheet.cell_value(row, 5))         

    r = sheet.nrows - 1    
    for i in range(0, r):
        link = X[i]                                
        page = requests.get(link).content         
        soup = BeautifulSoup(page, "html.parser")
        with open(r"C:\Users\singh\Downloads\Assignment\Solution\1. Extracted Data\Output{}.txt".format(i+1), "w") as output_file:
            print(soup.prettify(encoding = "utf-8"), file = output_file)
        
        
          
    
    


    
    
