# -*- coding: utf-8 -*-

import re
from nltk.tokenize import word_tokenize
from Stopwords import stopwords_currencies, stopwords_datesandnumbers, stopwords_generic, stopwords_generic_long, stopwords_geographic, stopwords_names
from Count import  constraining_word_count
from openpyxl import load_workbook

currencies_stopwords = stopwords_currencies(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_Currencies.txt")
        
datesandnumbers_stopwords = stopwords_datesandnumbers(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_DatesandNumbers.txt")
        
generic_stopwords = stopwords_generic(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_Generic.txt")
        
genericlong_stopwords = stopwords_generic_long(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_GenericLong.txt")
        
geographic_stopwords = stopwords_geographic(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_Geographic.txt")
        
names_stopwords = stopwords_names(r"C:\Users\singh\Downloads\Assignment\Solution\Stopwords\StopWords_Names.txt")

def constraining_word_count_whole_report():
    """Number of constraining words for the whole report
    
    This function calculates the number of constraining words of each report after HTML parsing
    
    Args:
        None
        
    Returns:
        None
    """
    cw_c = []
    
    for i in range(1, 153):
        try:
            with open(r"C:\Users\singh\Downloads\Assignment\Solution\2. Parsed HTML Data\Output{}.txt".format(i), 'r') as in_file:
                input_file = in_file.read()
                
                
        except FileNotFoundError as fnf_error:
            cw_c.append(None)
            continue
        
        input_file = input_file.lower()
        input_file = input_file.replace('/', ' / ')
        w = word_tokenize(input_file)
        for j, s in enumerate(w):
            if '\'s' in s:
                w[j-1] = w[j-1] + w[j]
                del w[j]
        
        p = re.compile('(?<!\d)\.|\.(?!\d)')
        w = [p.sub('', x) for x in w]
        p = re.compile("(?<!\w)\'|[\(\)\$,`\-&?\"\!\:;\=\/]")
        w = [p.sub('', x) for x in w]
        w = [x for x in w if x]
        
        X = []
        for word in w:
            if not word in set(generic_stopwords):
                X.append(word)
        
        w = X
        X = []
        for word in w:
            if not word in set(currencies_stopwords):
                X.append(word)
                  
        w = X
        X = []        
        for word in w:
            if not word in set(datesandnumbers_stopwords):
                X.append(word)
        
        w = X
        X = []        
        for word in w:
            if not word in set(genericlong_stopwords):
                X.append(word)
        
        w = X
        X = []        
        for word in w:
            if not word in set(geographic_stopwords):
                X.append(word)
                
        w = X
        X = []
        for word in w:
            if not word in set(names_stopwords):
                X.append(word)
        
        w = X
        for word in w:
            input_file = ' '.join(w)
     
        cw_c.append(constraining_word_count(r"C:\Users\singh\Downloads\Assignment\constraining_dictionary.xlsx", w))

    wb = load_workbook(r"C:\Users\singh\Downloads\Assignment\Solution\Output Data Structure.xlsx")

    sheet = wb.active

    row=2
    while(row <= 153):
        row=2
        for x in cw_c:
            sheet.cell(row, 49, x)
            row+=1
   
    wb.save(r"C:\Users\singh\Downloads\Assignment\Solution\Output Data Structure.xlsx")
