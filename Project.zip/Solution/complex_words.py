# -*- coding: utf-8 -*-

def complex_words_count(words_list: list):
    """Complex Words Count
    
    This function calculates the number of complex words in a list of words
    
    Complex Words are those words with more than 2 syllables, while not including 'es' or 'ed' as a syllable.
    
    Args:
        words_list (list): List of words
        
    Returns:
        int: The return value. Number of complex words    
    """
    cw_count = 0
    vowels = ['a', 'e', 'i', 'o', 'u']
    for word in words_list:
        syl_count = 0
        for w in vowels:    
            if w in word and word[-2:len(word)] != 'es | ed':
                syl_count+=1
        if syl_count > 2:
            cw_count+=1

    return cw_count
    
import Count
from Count import word_count 

def complex_words_percent(words_list = None):
    """Complex Words Percent
    
    This function calculates the percent of complex words in a list of words
        
    Args:
        words_list (list, optional): List of words. Defaults to None
        
    Returns:
        float: The return value. Percent of complex words    
    """
    if words_list is None:
        words_list = Count.w0
    cwc = complex_words_count(words_list)
    wc = word_count(words_list)
    percent_cw = cwc/wc
    
    return percent_cw


    
