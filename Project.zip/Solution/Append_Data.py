# -*- coding: utf-8 -*-

import openpyxl as xl
import xlrd

def workbook():
    """Workbook Function
    
    It is used to append data copied from a XLSX file to another file 

    Args:
        None
    
    Returns:
        None
    """
    wb = xlrd.open_workbook(r"C:\Users\singh\Downloads\Assignment\cik_list.xlsx")
    
    sheet = wb.sheet_by_index(0)
    
    X0 = []; X1 = []; X2 = []; X3 = []; X4 = []; X5 = []
    for row in range(0, sheet.nrows):
        X0.append(sheet.cell_value(row, 0))
        X1.append(sheet.cell_value(row, 1))
        X2.append(sheet.cell_value(row, 2))
        X3.append(sheet.cell_value(row, 3))
        X4.append(sheet.cell_value(row, 4))
        X5.append(sheet.cell_value(row, 5))
        
        
    rb = xl.Workbook()
    
    sheet1 = rb.create_sheet(title = "Sheet1", index=0)
    
    r = sheet.nrows 
    
    row=1
    while(row <= r):
        row=1
        for x in X0:
            sheet1.cell(row, 1, x)
            row+=1
        row=1
        for x in X1:
            sheet1.cell(row, 2, x)
            row+=1
        row=1
        for x in X2:
            sheet1.cell(row, 3, x)
            row+=1
        row=1
        for x in X3:
            sheet1.cell(row, 4, x)
            row+=1
        row=1
        for x in X4:
            sheet1.cell(row, 5, x)
            row+=1
        row=1
        for x in X5:
            sheet1.cell(row, 6, x)
            row+=1
            
    rb.save(r"C:\Users\singh\Downloads\Assignment\Solution\Output Data Structure.xlsx")
    
    wb = xlrd.open_workbook(r"C:\Users\singh\Downloads\Assignment\Output Data Structure.xlsx")
    
    sheet = wb.sheet_by_index(0)
    
    X6 = []
    
    for col in range(6, sheet.ncols):
        X6.append(sheet.cell_value(0, col))
        
    rb = xl.load_workbook(r"C:\Users\singh\Downloads\Assignment\Solution\Output Data Structure.xlsx")
    
    sheet1 = rb.active
    
    c = sheet.ncols
    
    col = 7
    while(col <= c):
        for x in X6:
            sheet1.cell(1, col, x)
            col+=1
            
    rb.save(r"C:\Users\singh\Downloads\Assignment\Solution\Output Data Structure.xlsx")
    
    
        
    
    



    

    
    



