# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------------------------
# Set the Current Directory as Present Working Directory in the IDE before executing the code
# -------------------------------------------------------------------------------------------
from Data_Extraction import extract_data
from Data_Parse import data_parse_html
import Append_Data
import mda
import qqdmr
import rf
from cw_c_whole_report import constraining_word_count_whole_report     

def main():
    extract_data(r"C:\Users\singh\Downloads\Assignment\cik_list.xlsx")
    data_parse_html()
    Append_Data.workbook()
    mda.analysis()
    qqdmr.analysis()
    rf.analysis()
    constraining_word_count_whole_report()

if __name__ == '__main__':
    main()    
