# -*- coding: utf-8 -*-
import re

def data_parse_html():
    """HTML Parsing of Data
    
    This function parses the HTML tags, aligns the data and reoves any insignificant words(if any)
    
    Args:
        None
        
    Returns:
        None
    """
    for i in range(1, 153):
        with open(r"C:\Users\singh\Downloads\Assignment\Solution\1. Extracted Data\Output{}.txt".format(i), 'r') as input_file:
            data = input_file.read()
            cleaned_text = data.replace(r'\n', '\n')
            cleaned_text = cleaned_text.replace(r'\t', '\t')
            cleaned_text = cleaned_text.replace('\\', '')
            cleaned_text = cleaned_text.replace('/bullet/', '')
            cleaned_text = re.sub('<[^>]+>', '', cleaned_text)
            with open(r"C:\Users\singh\Downloads\Assignment\Solution\2. Parsed HTML Data\Output{}.txt".format(i), 'w', encoding="utf-8") as output_file:
                print(cleaned_text, file = output_file)
        
                            


