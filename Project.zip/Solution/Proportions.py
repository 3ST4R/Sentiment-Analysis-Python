# -*- coding: utf-8 -*-
import Count
from Count import word_count, constraining_word_count, uncertainty_word_count
import Scores
from Scores import positive_score, negative_score

def positive_word_proportion(filepath = None, words_list = None):
    """Positive Words Proportion
    
    This function calculates the positive words proportion.
    
    Args:
        filepath (str, optional): File path of Positive words dictionary in TXT format
        words_list (list, optional): List of words
    
    Returns: 
        float: The return value. Positive Words Proportion 
    """
    if filepath is None:
        filepath = Scores.f1
    if words_list is None:
        words_list = Count.w0
    positive_scr = positive_score(filepath, words_list)
    wc = word_count(words_list)
    
    positive_wp = positive_scr/wc
    
    return positive_wp

def negative_word_proportion(filepath = None, words_list = None):
    """Negative Words Proportion
    
    This function calculates the negative words proportion.
    
    Args:
        filepath (str, optional): File path of Negative words dictionary in TXT format
        words_list (list, optional): List of words
    
    Returns: 
        float: The return value. Negative Words Proportion 
    """
    if filepath is None:
        filepath = Scores.f2
    if words_list is None:
        words_list = Count.w0
    negative_scr = negative_score(filepath, words_list)
    wc = word_count(words_list)
    
    negative_wp = negative_scr/wc
    
    return negative_wp

def constraining_word_proportion(filepath = None, words_list = None):
    """Constraining Words Proportion
    
    This function calculates the constraining words proportion.
    
    Args:
        filepath (str, optional): File path of constraining words dictionary in XLSX format
        words_list (list, optional): List of words
    
    Returns: 
        float: The return value. Constraining Words Proportion 
    """
    if filepath is None:
        filepath = Count.f_0
    if words_list is None:
        words_list = Count.w0
    constraining_wc = constraining_word_count(filepath, words_list)
    wc = word_count(words_list)
    
    constraining_wp = constraining_wc/wc
    
    return constraining_wp

def uncertainty_word_proportion(filepath = None, words_list = None):
    """Uncertainty Words Proportion
    
    This function calculates the uncertainty words proportion.
    
    Args:
        filepath (str, optional): File path of uncertainty words dictionary in XLSX format
        words_list (list, optional): List of words
    
    Returns: 
        float: The return value. Uncertainty Words Proportion 
    """
    if filepath is None:
        filepath = Count.f_1
    if words_list is None:
        words_list = Count.w0
    uncertainty_wc = uncertainty_word_count(filepath, words_list)
    wc = word_count(words_list)
    
    uncertainty_wp = uncertainty_wc/wc
    
    return uncertainty_wp