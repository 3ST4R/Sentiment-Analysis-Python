# -*- coding: utf-8 -*-
f1 = ''
def positive_score(filepath: str, words_list: list):
    """Positive Score
       
    This function calculates the number of positive words in the list of words.
    
    Args:
        filepath (str): File path of Positive words dictionary in TXT format
        words_list (list): List of words
    
    Returns:
        int: The return value. Positive Score
    """
    global f1
    f1 = filepath
    with open(filepath, 'r') as positives:
        lm_positives = {x.lower() for x in positives}
        lm_positives = {x.replace('\n', '') for x in lm_positives}
        lm_positives = {x.replace(' ', '') for x in lm_positives}
        
        a = []
        
        for word in words_list:
            for p in set(lm_positives):
                if p == word:
                    a.append(1)
        
        return sum(a)
f2 = ''
def negative_score(filepath: str, words_list: list):
    """Negative Score
       
    This function calculates the number of negative words in the list of words.
    
    Args:
        filepath (str): File path of Negative words dictionary in TXT format
        words_list (list): List of words
    
    Returns:
        int: The return value. Negative Score
    """
    global f2
    f2 = filepath
    with open(filepath, 'r') as negatives:
        lm_negatives = {x.lower() for x in negatives}
        lm_negatives = {x.replace('\n', '') for x in lm_negatives}
        lm_negatives = {x.replace(' ', '') for x in lm_negatives}
        
        a = []
        
        for word in words_list:
            for p in set(lm_negatives):
                if p == word:
                    a.append(-1)
             
        
        return sum(a)*(-1)

def polarity_score(words_list: list, filepath1 = None, filepath2 = None):
    """Polarity Score
       
    This function calculates the polarity score of the list of words.
    
    Args:
        words_list (list): List of words
        filepath1 (str, optional): File path of Positive words dictionary in TXT format. Defaults to None
        filepath2 (str, optional): File path of Negative words dictionary in TXT format. Defaults to None
    
    Returns:
        float: The return value. Polarity Score
    """
    if filepath1 is None:
        filepath1 = f1
    if filepath2 is None:
        filepath2 = f2
    positive_scr = positive_score(filepath1, words_list)
    negative_scr = negative_score(filepath2, words_list)
    
    polarity_scr = (positive_scr - negative_scr)/((positive_scr + negative_scr) + 0.000001)
    
    return polarity_scr

